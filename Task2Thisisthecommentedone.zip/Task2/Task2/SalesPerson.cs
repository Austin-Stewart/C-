﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Task2
{
    class SalesPerson
    {
        //Class properties
        public string name;
        public int level;
        public double sales;
        public double hoursWorked;
        //constructor
        public SalesPerson(string name, int level, double sales, double hoursWorked)
        {
            this.name = name;
            this.level = level;
            this.sales = sales;
            this.hoursWorked = hoursWorked;
        }
//Method to calculate the bonus for salespeople objects
        public double CalculateBonus()
        {
            if(this.sales > 24000) { return this.sales * 3 / 100; }
            else
            {
                return 0;
            }
        }
        //Method to calculate the commission for salespeople objects
                public double CalcCommission()
        {
            //level 1 path
            if (this.level == 1)
            {
                if (this.sales <= 2000) {
                    double rate = 5.25 / 100;
                    double commission = this.sales * rate;
                    return commission;
                }
                //If sales is greater than $2000 but less than $3500, the rate is 7.5 percent.
                else if (this.sales > 2000 && this.sales < 3500)
                {
                    double rate = 7.5 / 100;
                    double commission = this.sales * rate;
                    return commission;
                }
                //If sales is equal to or greater than $3500, the rate is 9.75 percent.
                else if (this.sales >= 3500)
                {
                    double rate = 9.75 / 100;
                    double commission = this.sales * rate;
                    return commission;
                }

            }
            //Level 2 path
            else if (this.level == 2)
            {
                //If sales is equal to or less than $2800, the rate is 6.5 percent.
                if (this.sales <= 2800)
                {
                    double rate = 6.5 / 100;
                    double commission = this.sales * rate;
                    return commission;
                }
                //If sales is greater than $2800, the rate is 7.75 percent.
                else if (this.sales > 2800)
                {
                    double rate = 7.75 / 100;
                    double commission = this.sales * rate;
                    return commission;
                }
            }
             
            else if (this.level == 3)
            {
                double rate = 8.5 / 100;
                double commission = this.sales * rate;
                return commission;
            }
            
            else if (this.level == 4)
            {
                double rate = 9.75 / 100;
                double commission = this.sales * rate;
                return commission;
            }
             
            else
            {
                Console.WriteLine("Error invalid level");
                double commission = 0;
                return commission;
            }
            return 0;
        }
        
        public double CalculatePay()
        {
            
            if (this.level == 1)
            {
                if (this.hoursWorked <= 40) {
                    double hourly_wages = this.hoursWorked * 13.5;
                    return hourly_wages;
                }
                 
                else
                {
                    double hourly_wages = ((this.hoursWorked - 40) * 13.5 * 1.5) + 13.5 * 40;
                    return hourly_wages; }
                            }
             
            else if (this.level == 2)
            {
                if (this.hoursWorked <= 40) {
                    double hourly_wages = this.hoursWorked * 15.75;
                    return hourly_wages;
                }
         
                else {
                    double hourly_wages = ((this.hoursWorked - 40) * 15.75 * 1.5) + 15.75 * 40;
                    return hourly_wages;
                }

            }
          
            else if (this.level == 3)
            {
                if (this.hoursWorked <= 40) {
                    double hourly_wages = this.hoursWorked * 18.25;
                    return hourly_wages;
                }
                
                else {
                    double hourly_wages = ((this.hoursWorked - 40) * 18.25 * 1.5) + 18.25 * 40;
                    return hourly_wages;
                }
            }
            
            else if (this.level == 4)
            {
                if (this.hoursWorked <= 40) {
                    double hourly_wages = this.hoursWorked * 20.75;
                    return hourly_wages; }
            
                else {
                    double hourly_wages = ((this.hoursWorked - 40) * 20.75 * 1.5) + 20.75 * 40;
                    return hourly_wages;
                }



            }
                else{
                    double hourly_wages = 0;
                    return hourly_wages;
            }
            
            
             }
        
        
        public double CalculateGrandTotal()
        {
            double GrandTotal = CalcCommission() + CalculatePay() + CalculateBonus();
            return GrandTotal;
        }


        //  Write a ToString method that returns a string containing: name, total wage pay (regular and overtime),commission, bonus and gross pay (total wage pay plus commission plus bonus). 
        public override string ToString()
        {
            return string.Format("Name:{0} Wage:${1} Commission:${2} Gross Pay:${3}", name, CalculatePay(), CalcCommission(), CalculateGrandTotal());
        }
    }
}

